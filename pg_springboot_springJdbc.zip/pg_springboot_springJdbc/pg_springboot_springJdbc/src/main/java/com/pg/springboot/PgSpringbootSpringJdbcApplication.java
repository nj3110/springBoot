package com.pg.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgSpringbootSpringJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgSpringbootSpringJdbcApplication.class, args);
	}

}
